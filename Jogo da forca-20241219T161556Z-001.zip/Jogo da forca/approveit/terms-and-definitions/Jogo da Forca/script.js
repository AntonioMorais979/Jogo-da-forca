let currentWord;
let guessedLetters = [];
let lives = 7;
const wordDisplay = document.getElementById('word-display');
const livesDisplay = document.getElementById('lives');
const letterInput = document.getElementById('letter-input');
const guessButton = document.getElementById('guess-btn');
const message = document.getElementById('message');
// Função para carregar os arquivos JSON no dropdown
function loadFileList(element) {
  const files = [
      { name: "../data/chess.json", label: "Xadrez" },
      { name: "../data/ing-family.json", label: "Palavras -ing" },
      { name: "../data/actions.json", label: "Ações" },
      { name: "../data/ing-family-short.json", label: "Palavras -ing" }
  ];

  files.forEach(file => {
      const option = document.createElement("option");
      option.value = file.name;
      option.textContent = file.label;
      element.appendChild(option);
  });
}

let timerSeconds = 0;
let timer;

// Função para iniciar o cronômetro
function startTimer(element) {
  timer = setInterval(() => {
      timerSeconds++;
      const minutes = Math.floor(timerSeconds / 60);
      const seconds = timerSeconds % 60;
      element.innerText = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }, 1000);
}

// Função para carregar as palavras do arquivo JSON selecionado e iniciar o jogo
async function loadWords(fileName) {
  const response = await fetch(fileName);
  const data = await response.json();
  return data.words;
  fetch(`../data/${fileName}.json`)
      .then(response => response.json())
      .then(data => {
          // Atualizar a variável currentWord com a palavra aleatória
          currentWord = data.words[Math.floor(Math.random() * data.words.length)];
          // Inicializar o display da palavra e outras variáveis do jogo
          initializeGame();
      })
      .catch(error => {
          console.error('Erro ao carregar o arquivo JSON:', error);
      });
}
async function getRandomWordFromFile(fileName) {
  const words = await loadWords(fileName);
  const randomIndex = Math.floor(Math.random() * words.length);
  return words[randomIndex];
}
async function startGame(selectedFile) {
  // Carrega as palavras do arquivo selecionado
  const words = await loadWords(selectedFile.name);

  // Escolhe uma palavra aleatória
  const randomIndex = Math.floor(Math.random() * words.length);
  const currentWord = words[randomIndex];

  // Inicializa o display da palavra (substitua com sua lógica)
  let displayWord = '';
  for (let i = 0; i < currentWord.length; i++) {
    displayWord += '_ ';
  }
  document.getElementById('word-display').textContent = displayWord;

  // Inicializa outras variáveis do jogo (vidas, letras chutadas, etc.)
  let lives = 5;
  let guessedLetters = [];

  // ... Resto da lógica do jogo (verificar chutes, atualizar display, etc.)

  // Exemplo de como verificar um chute:
  function checkGuess(guess) {
    // ... sua lógica para verificar se a letra está na palavra,
    // atualizar o display, e verificar se o jogador ganhou ou perdeu
  }
}
function initializeGame(category) {
  guessedLetters = [];
  wordDisplay.textContent = '';
  const randomIndex = Math.floor(Math.random() * categories[category].length);
  currentWord = categories[category][randomIndex];
  lives = currentWord.length + 3;
  livesDisplay.textContent = lives;
  createWordDisplay();
}

function createWordDisplay() {
  for (let i = 0; i < currentWord.length; i++) {
    const letterSpan = document.createElement('span');
    letterSpan.textContent = '_';
    wordDisplay.appendChild(letterSpan);
  }
}

function updateWordDisplay() {
  let displayWord = '';
  for (let i = 0; i < currentWord.length; i++) {
    if (guessedLetters.includes(currentWord[i])) {
      displayWord += currentWord[i];
    } else {
      displayWord += '_';
    }
  }
  wordDisplay.textContent = displayWord;
}

function checkGuess(letter) {
  const guess = letterInput.value.toLowerCase();
  guessedLetters.push(guess);

  letterInput.value = '';
  if (guessedLetters.includes(letter)) {
    messageDisplay.textContent = 'Você já chutou essa letra!';
    return;
  }

  guessedLetters.push(letter);

  let correctGuesses = 0;
  for (let i = 0; i < currentWord.length; i++) {
    if (currentWord[i] === letter) {
      wordDisplay.children[i].textContent = letter;
      correctGuesses++;
    }
  }

  if (correctGuesses === 0) {
    lives--;
    livesDisplay.textContent = lives;
    if (lives === 0) {
      endGame(false);
    }
  } else if (checkWin()) {
    endGame(true);
  }
  livesDisplay.textContent = lives;
}

function checkWin() {
  return wordDisplay.textContent.replace(/\s/g, '') === currentWord;
}

function endGame(won) {
  letterInput.disabled = true;
  guessButton.disabled = true;
  messageDisplay.textContent = won ? 'Parabéns, você venceu!' : 'Você perdeu! A palavra era: ' + currentWord;
}
// Carregar os arquivos JSON no dropdown ao carregar a página
loadFileList(document.getElementById('file-dropdown'));

// Evento para quando um assunto é selecionado
document.getElementById('file-dropdown').addEventListener('change', () => {
  const selectedFile = document.getElementById('file-dropdown').value;
  loadWords(selectedFile);
  startTimer(document.getElementById('timer'));
}
);